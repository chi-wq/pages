# Repository Guidelines

This template bootstraps a Genshin-TS project. Maintain it with user workflow and compile outputs in mind.

## Read First

- `STRUCTURE.md`: full project structure tree with file annotations.
- `NOTES.md`: resolved issues, gsts constraints, maintenance notes.
- `README.md`: full usage flow, constraints, and global function cheat sheet.
- `UPDATE.md`: version update comparison (main vs add_ver0.04_features).

## Layout

- `NOTES.md`: resolved issues and gsts constraints reference
- `STRUCTURE.md`: project tree reference
- `UPDATE.md`: version diff between main and add_ver0.04_features
- `src/main.ts`: entry point, imports all graphs
- `src/config/`: stage config, game constants, rule text, spawn slots
- `src/graphs/`: node graph definitions (6 files, one per graph)
- `src/graph-variables/`: node graph variable definitions (dict templates etc.)
- `src/systems/`: business logic systems (5 files)
- `src/utils/`: utility functions (3 files: stageUtils, enemyPrefabs, logger)
- `src/resources/`: auto-generated (do not edit)
- `gsts.config.ts`: compile config (entries/outDir/inject)
- `dist/`: build outputs (generated)
- `README.md`: user guide (Chinese)
- `CLAUDE.md`: AI rules
- `STRUCTURE.md`: project tree reference

## Typical Workflow

1. Update the NodeGraph ID in `src/main.ts`
2. Add `inject` in `gsts.config.ts` when needed
3. Run `npm run dev` for incremental compile

## Coding and Maintenance Rules

- Update `entries` when adding new entry files.
- Entry events use `g.server({ id }).on(...)`; same ID entries merge automatically.
- `gstsServer*` must be top-level and only allow a single trailing `return`.
- Avoid Promise/async/recursion/JSON/Object in graph scope.
- Conditions must be `boolean`; use `bool(...)` when needed.
- Use `bigint` for integer ops; avoid modulo/bitwise on `number`.
- `while(true)` is capped; use timers or explicit counters.
- Empty arrays must have inferable element types.
- Logging: use `print(str(...))` or `console.log(x)` (single argument).
- Use type helpers when needed: `int/float/str/bool/vec3/configId/prefabId/entity`.

## Node Graph Variables

- Declare with `g.server({ variables: { ... } })`.
- Read/write via `f.get` / `f.set`, keep types aligned.

## Debugging Outputs

- `.gs.ts`: verify compiled node calls
- `.json`: verify connections and types
- `.gia`: final injectable output

## Common Scripts

- `npm run dev`
- `npm run build`
- `npm run maps`
- `npm run backup`

## Reference Definitions

- Search function/event comments in `node_modules/genshin-ts/dist/src/definitions/`.
